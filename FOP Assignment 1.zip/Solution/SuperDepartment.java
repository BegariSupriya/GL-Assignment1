package com.greatLearning.assignment;

public class SuperDepartment {

	public String deparmentName() {
		return " Super Deparment  ";
	}

	//declare method getTodaysWork of return type string
	public String getTodaysWork() {
		return " No work as of now ";
	}

	//declare method getWorkDeadline of return type string
	public String getWorkDeadline() {
		return " Nil ";
	}
	
	//declare method isTodayAHoliday of type string 
	public String isTodayAHoliday() {
		return "Today is not a Holiday";
	}
}
